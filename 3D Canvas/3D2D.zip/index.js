
const canvasSketch = require('canvas-sketch');
const { Vector } = require('p5');

const {PerspectiveMatrix,CreateScaleMatrix, RotationMatrix, PrintMatrix, WorldToImageMatrix, CameraProject,MatrixMultiply} = require('./Transformations');


// Grab P5.js from npm
const p5 = require('p5');

// Attach p5.js it to global scope
new p5()

const settings = {
  // Tell canvas-sketch we're using p5.js
  p5: true,

  animate: true,

  dimensions: [2048, 2048],
  resizeCanvas: true,
  // Enable MSAA
  attributes: {
    antialias: true
  }
};


// Optionally preload before you load the sketch
window.preload = () => {
  // Preload sounds/images/etc...

};

var sketch = canvasSketch(() => {
  // Inside this is a bit like p5.js 'setup' function
  // ...
  Setup();


  
  // DrawFlowField(100, 100, color(255, 0, 0));
  // Attach events to window to receive them
  window.mouseClicked = ()   => {
   
   
  };
 

  // resizeCanvas(settings.dimensions[0], settings.dimensions[1]);

  // Return a renderer to 'draw' the p5.js content
  return ({ playhead, width, height }) => {
    // Draw with p5.js things
    // set background color
   background(0);
    Draw(); 
 
    

  };
}, settings);

const vertices = [[0.0, 0.0, 0.007], [0.01, 0.0, 0.01], [-0.0, 0.0034, 0.007],
 [-0.0, 0.0034, 0.007], [-0.0, 0.0, -0.01], [-0.01, 0.0, 0.01], 
 [-0.0, 0.0, -0.01], [0.01, 0.0, 0.01], [-0.0, 0.0, 0.007], [-0.01, 0.0, 0.01],
  [-0.01, 0.0, 0.01], [-0.0, 0.0, 0.007], [-0.0, 0.0034, 0.007], [-0.0, 0.0034, 0.007], 
  [0.01, 0.0, 0.01], [-0.0, 0.0, -0.01]];

const faces = [[1, 2, 3], [1, 5, 6], [5, 2, 9], [9, 10, 5], [11, 12, 13], [14, 2, 5]];

const CameraProperties = {
  position: new Vector(0, 0, 0),
  up : new Vector(0, 1, 0),
  fov : PI / 4,
  target: new Vector(0, 0, 0),      // Camera always looks towards world center
  near: 0.01,
  far: 100,
  aspect: settings.dimensions[0] / settings.dimensions[1]
}

let points = []; 
function Setup()
{
  
}




function Draw ()
{

  
  let points = []; 

  if(mouseIsPressed)
  {
    CameraProperties.position = new Vector(mouseX/100 ,mouseY/100,3);
  }


  
  // CameraProperties.position = new Vector(mouseX/100 ,mouseY/100,3);

  scaleMatrix = CreateScaleMatrix(50); 

  

  // Perspective Matrix: Confirmed working
 
  Xpi = PerspectiveMatrix(CameraProperties.fov, CameraProperties.aspect, CameraProperties.near, CameraProperties.far);
  PrintMatrix(Xpi,4,4); 

  // World to Image: Confirmed working

  Xiw = WorldToImageMatrix(CameraProperties.position, CameraProperties.target, CameraProperties.up);
  print("Xiw");
  PrintMatrix(Xiw,4,4);

  //rotationMatrix
  Xr = RotationMatrix(0,0,0);
  PrintMatrix(Xr,4,4);
  // scaleMatrix = MatrixMultiply(scaleMatrix,Xr);
  
  Xpi = MatrixMultiply( Xpi,scaleMatrix);
  Xpw = MatrixMultiply( Xiw,Xpi);

 
  let viewport = [0, 0, settings.dimensions[0], settings.dimensions[1]];

  print(vertices.length)
  for(let i = 0; i < vertices.length; i++)
  {
    let projectedPoint = CameraProject(vertices[i],viewport,0,1,Xpw);
    points.push(projectedPoint);
  }

  print(points.length);

  for(let i = 0; i < points.length; i++)
  {
    // stroke(255);
    // strokeWeight(30);
    point(points[i][0],points[i][1]);
    textSize(20);
    fill(255);
    // text(i,points[i][0],points[i][1]);
    // console.log(points[i][0],points[i][1]);
   
  }


  // Connect points based on faces index 
  for(let i = 0; i < faces.length; i++)
  {
    strokeWeight(5);

    let face = faces[i];
    let p1 = points[face[0] - 1];
    let p2 = points[face[1] - 1];
    let p3 = points[face[2] - 1];

    noFill();
    stroke(255);
    line(p1[0],p1[1],p2[0],p2[1]);
    line(p2[0],p2[1],p3[0],p3[1]);
    line(p3[0],p3[1],p1[0],p1[1]);
  
  }

}

function UpdateCamera()
{
  CameraProperties.position = new Vector(3,2,1);


}




